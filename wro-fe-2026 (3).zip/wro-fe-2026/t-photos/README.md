# t-photos

- `team-official.jpg` — ✅ in place, referenced in §0 of the main README
- `team-funny.jpg` — ❌ still needed (informal photo, all members visible)

Both are required. Delete this file once the second photo is added.
