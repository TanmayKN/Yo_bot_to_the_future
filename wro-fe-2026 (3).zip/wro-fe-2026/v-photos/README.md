# v-photos

Six views required — every side, plus top and bottom.

| File | Status | Notes |
|---|---|---|
| `front.jpg` | ✅ | Forward ultrasonics + camera mount, front axle visible |
| `back.jpg` | ✅ | Along-deck view: rear panel, battery pack, Pi, front frame |
| `right.jpg` | ✅ | Full side profile |
| `left.jpg` | ❌ | Mirror of `right.jpg` |
| `top.jpg` | ❌ | Shoot from directly overhead — sensor placement + I²C run |
| `bottom.jpg` | ❌ | Drive train + steering linkage (where Ackermann is visible) |
| `hero-front-quarter.jpg` | ✅ | Not required; used as the README header image |

**Verify `right.jpg` is the right side.** With the nose pointing to the right of frame, the
camera sees the vehicle's right flank. If your front axle is at the other end, swap the
`right.jpg` / `left.jpg` names.

For the three remaining shots, match the existing ones: same plain background, same
distance, vehicle in competition condition with the harness tidy and no test leads
attached. `bottom.jpg` needs the car inverted — support it on blocks so nothing rests on
the camera mast.

Delete this file once all six required views are in place.
