# WRO Future Engineers 2026 — Autonomous Vehicle

**Team:** Yo_Bot_To_The_Future · **Country:** India · **Category:** Future Engineers

An autonomous 1/10-scale-style vehicle built on a custom **Ackermann steering chassis**, powered by a **3S Li-ion pack (11.1 V nominal)**, using **three ultrasonic rangefinders** and an **MPU-6050 IMU** for navigation, with steering driven through a **PCA9685 I²C PWM controller** and propulsion through an **L298N H-bridge**.

---

## Contents

1. [Team](#1-team)
2. [Vehicle Overview](#2-vehicle-overview)
3. [Design Summary](#3-design-summary)
4. [Repository Structure](#4-repository-structure)
5. [Vehicle Photos](#5-vehicle-photos)
6. [Quick Start](#6-quick-start)
7. [Full Documentation](#7-full-documentation)
8. [Commit & Release Practice](#8-commit--release-practice)

---

## 1. Team

![Team photo](t-photos/team-official.jpg)

*Team Yo_Bot_To_The_Future. `[FILL: set the left-to-right order to match the photo]`*

| | |
|---|---|
| **Team name** | Yo_Bot_To_The_Future |
| **Country** | India |
| **Academy** | Yolabs |
| **Coach** | Rahul Sharma |
| **Category** | Future Engineers |
| **Season** | 2026 |

| Member | Role |
|---|---|
| **Tanmay** | Team leader — coding and design |
| **Vedant** | Technical documentation and design |
| **Anshuman** | Electronics and building |

An informal team photo is at [`t-photos/team-funny.jpg`](t-photos/team-funny.jpg). Both photos are required by the rules.

---

## 2. Vehicle Overview

| Property | Value |
|---|---|
| Chassis type | Ackermann steering, rear-wheel drive |
| Wheelbase (L) | `[FILL: mm]` |
| Track width (W) | `[FILL: mm]` |
| Overall L × W × H | `[FILL]` mm — **see envelope check below** |
| Mass (ready to run) | `[FILL: g]` |
| Drive motor | `[FILL: model]` geared DC, via L298N |
| Steering actuator | 1 × `[FILL: servo model]` via PCA9685 channel 0 |
| Controller | ESP32 `[FILL: board variant]` |
| Battery | 3 × 18650 Li-ion in series (3S1P), 11.1 V nom / 12.6 V full |
| Distance sensing | 3 × HC-SR04 ultrasonic (left, right, front) |
| Orientation sensing | MPU-6050 6-axis IMU (I²C) |

![Vehicle, front three-quarter view](v-photos/hero-front-quarter.jpg)

### Envelope check

Rules 11.1 and 11.2 cap the vehicle at **300 × 200 mm footprint, 300 mm height, 1.5 kg**.
The chassis STL measures **198.5 × 269.9 × 78.8 mm**, which clears the footprint by
**1.5 mm on the 200 mm axis** — 0.75 mm per side.

| Limit | Rule | Chassis STL | Margin |
|---|---|---|---|
| ≤ 300 mm | 11.1 | 269.9 mm | 30.1 mm |
| ≤ 200 mm | 11.1 | 198.5 mm | **1.5 mm** |
| ≤ 300 mm height | 11.1 | 78.8 mm | 221.2 mm |
| ≤ 1.5 kg | 11.2 | `[FILL]` | `[FILL]` |

That 1.5 mm is the bare printed chassis. It does not include tyre bulge, sensor faces,
cable runs or the camera mast. **Measure the assembled vehicle with calipers across its
widest point before the competition** — judges check dimensions at every check time with a
cube or folding rule, and a vehicle that fails gets one three-minute window to fix it
(rule 12.8) before it cannot be used.

---

---

## 3. Design Summary

The full engineering reasoning lives in the [Engineering Journal](https://docs.google.com/document/d/1gzAN5yuOLNeTZ4LsddFFwpJb-0twvpmjZjD0ZiJfHyQ/edit?usp=sharing). This section is the short version —
the four decisions that shaped everything else.

### Ackermann steering, not differential

Skid steering scrubs its wheels laterally through every turn, so the same motor command
produces a different heading change depending on grip, load and battery voltage. Ackermann
wheels roll along their own arcs, which makes turn radius deterministic and keeps wheel
odometry valid. The cost is that the vehicle cannot pivot in place, so recovery from a
nose-in wall contact needs an explicit reverse state in software.

### Sensor refresh rate sets the speed ceiling

Three HC-SR04 ultrasonics are polled round-robin with a fixed gap so they cannot hear each
other's pings. That fixes the full-system refresh rate — and top speed is chosen so the
vehicle always gets several distance samples before it could reach a wall from detection
range. Driving faster than the sensors update means driving blind between samples. This is
why an electrical choice constrained the mechanical gearing.

### The Pi sees, the ESP32 drives

The camera and the vision pipeline run on the Raspberry Pi; steering and motor
output stay on the ESP32. The split is not about processing power — it is that the
ESP32 has a deterministic loop with no operating system scheduler between it and the
servo, and the Pi has neither. So the Pi is never in the loop that keeps the car
between the walls. If the Pi stalls or dies mid-run, the ESP32 keeps wall-following
on ultrasonics alone: degraded, but still driving.

They talk over UART2 at 115200. The Pi sends one line per frame — `PIL,red,-12.3`
— giving the colour it can see and how many degrees left or right of centre it is.

**This subsystem is half built.** The camera pipeline and the serial message work;
the colour detection is not calibrated and the ESP32 does not read the messages yet.

→ [`pi/`](pi/)

### Two side sensors, so each can check the other

On a straight section, `left + right` should equal the lane width minus vehicle width and
stay constant. When it doesn't, one reading is lying — usually a specular reflection off an
angled wall — and the frame is rejected rather than steered on. A single side sensor gives
no way to detect that it's wrong.

### The servo gets its own power rail

The steering servo draws up to ~1.2 A on stall. Routing it through a buck converter to the
PCA9685's `V+` keeps those spikes off the MCU board entirely, removing a real brown-out
path. The PCA9685's `VCC` and `V+` are **not** interchangeable — wiring the servo rail into
`VCC` back-feeds 6 V into the ESP32's 3.3 V rail and destroys the board.

---

## 4. Repository Structure

Folder names follow the WRO Future Engineers specification. They are kept exactly as
specified even where a different name would read more naturally, because judges look for
these names.

```
/
├── README.md            ← this document
│
├── t-photos/            ← team photos (official + informal)
├── v-photos/            ← vehicle photos (all sides, top, bottom)
├── schemes/             ← pinout and wiring diagrams
├── pi/                  ← Raspberry Pi vision node (half built)
│   ├── vision.py        (finds red/green pillars)
│   ├── main.py          (main loop)
│   └── calibrate.py     (colour calibration)
│
├── src/                 ← ESP32 control software
├── models/              ← STL + print settings
│   ├── chassis/         (assembly, part_106, part_107, axle_adaptor)
│   └── camera/          (pi mount, front box, back cover)
├── other/               ← BOM, datasheets, superseded code
```

**`models/` carries the Fusion 360 source, not just STLs.** A mesh can be printed but not
modified. Shipping the `.f3d` means the design is genuinely reproducible.

**`other/legacy/` keeps superseded code deliberately.** Each version is paired with an entry
in the iteration log explaining what changed and why. Old files alone score nothing; old
files with the reasoning attached are iteration evidence.

---

## 5. Vehicle Photos

Six views are required — every side, plus top and bottom.

| | |
|---|---|
| ![Front](v-photos/front.jpg) **Front** | ![Back](v-photos/back.jpg) **Back** |
| ![Right](v-photos/right.jpg) **Right** | ![Left](v-photos/left.jpg) **Left** |
| ![Top](v-photos/top.jpg) **Top** | ![Bottom](v-photos/bottom.jpg) **Bottom** |

The **front** view shows the two forward ultrasonic sensors flanking the camera mount, and
the splayed front axle where the Ackermann linkage sits. The **back** view looks along the
deck: rear body panel, then the 3S 18650 pack, then the Raspberry Pi, then the front frame
and camera mast — the front-to-rear mass distribution described in the mechanical
documentation.

Still to shoot: **left**, **top**, **bottom**. The top view should capture sensor placement
and the I²C run; the bottom view should show the drive train and steering linkage, since
that is where the Ackermann geometry is actually visible.

## 6. Quick Start

Full step-by-step instructions, including the mechanical assembly order and the pre-run
checklist, are in the [Engineering Journal](https://docs.google.com/document/d/1gzAN5yuOLNeTZ4LsddFFwpJb-0twvpmjZjD0ZiJfHyQ/edit?usp=sharing).

```bash
git clone [REPO URL]
cd [REPO]
pio run -t upload            # PlatformIO
pio device monitor -b 115200
```

Three things to verify **before** anything is powered up, each of which has destroyed
hardware at least once:

| Check | Why |
|---|---|
| Every ECHO divider outputs ~3.3 V | HC-SR04 outputs 5 V logic; ESP32 GPIO are not 5 V tolerant |
| Buck set to 6.0 V **with no load connected** | Standard servos are rated 4.8–7.2 V |
| L298N `ENA` jumper removed | Left fitted, the motor ignores PWM and runs flat out |

Then run an I²C scan. Expect `0x40` (PCA9685) and `0x68` (MPU-6050). If either is missing,
stop and check grounds before going further — every board must share a common ground
reference.

All tunable values live in [`src/config.h`](src/config.h). Start from the committed
defaults and re-tune `Kp`/`Kd` for your surface.

---

## 7. Full Documentation

**→ [Engineering Documentation V4 (Google Doc)](https://docs.google.com/document/d/1gzAN5yuOLNeTZ4LsddFFwpJb-0twvpmjZjD0ZiJfHyQ/edit?usp=sharing)**

The complete engineering journal. Covers all five judging criteria: mobility and
mechanical design, power and sensor architecture, software architecture and obstacle
strategy, systems thinking and engineering decisions, and reproducibility.

The document is publicly readable without sign-in — verified.

Diagrams are also kept in this repository under [`schemes/`](schemes/), because the
repository has to be usable on its own: a link can break, and Criterion 2 asks for a
wiring diagram to be provided as part of the submission rather than referenced elsewhere.

---

## 8. Commit & Release Practice

Commit messages state **what changed and why it matters**, in the imperative. No numbering.

```
Add ESP32 pin map and system block diagram
Add rendered previews of the 3D printed parts
Add software architecture and detection overlay images
Reduce servo rail to 6.0 V, was above servo voltage rating
Freeze PID integral during turns to stop corner overshoot
```

The rules require at least three commits, timed backwards from the competition date:
the first no later than two months before and carrying at least a fifth of the final
code, the second no later than one month before, and the third no later than two weeks
before. That third commit is the one judges score.

Releases are tagged at each competition-ready state (`v1.0-regional`, `v2.0-national`).
The repository stays public from submission through at least 12 months after the event.

