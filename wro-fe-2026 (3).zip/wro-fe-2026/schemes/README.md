# schemes

Schematic diagrams of all electromechanical components and how they connect.
Accepted formats: JPEG, PNG, PDF.

## Needed here

| File | Status |
|---|---|
| `pinout_esp32.png` | ❌ export from the engineering journal |
| `wiring_system.png` | ❌ export from the engineering journal |

Both diagrams already exist inside the Google Doc. They still need to be exported
as image files and committed here.

**Why the journal alone is not enough.** Criterion 2's level-4 descriptor requires a
wiring diagram to be *provided*, and Criterion 5 asks whether another team could
reproduce the robot from the repository. A repository that outsources its schematics
to an external link fails both if that link is slow, moved, or permission-changed on
the day a judge opens it. The journal is the narrative; the repository has to stand
on its own.

## How to export

In the Google Doc, right-click each diagram → **Save to Keep**, or download the whole
document as a web page (File → Download → Web Page) and pull the images out of the
`images/` folder in the resulting zip. Rename to the filenames above.

If the diagrams were generated from SVG source, commit the SVG alongside the PNG —
an editable source is worth more than a flat image when a pin assignment changes.
