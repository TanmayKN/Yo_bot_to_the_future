#!/usr/bin/env python3
"""
main.py - Raspberry Pi vision node.

Looks for a pillar, sends what it sees to the ESP32 over the serial cable.

    python3 main.py             normal
    python3 main.py --show      show the camera window (bench testing)

The message sent looks like this:

    PIL,red,-12.3

The Pi only reports what it SEES. The ESP32 decides what the car DOES.
That is on purpose: the ESP32 runs a steady timed loop with nothing else
competing for it, and the Pi does not. So if the Pi crashes, the ESP32 keeps
following the walls with the ultrasonics and the car keeps driving.
"""

import sys
import time
import serial
import vision

PORT = "/dev/serial0"
BAUD = 115200
RATE = 20        # times per second


def main():
    show = "--show" in sys.argv

    cam = vision.open_camera()
    if not cam.isOpened():
        print("Camera did not open. Check the ribbon cable.")
        return 1

    try:
        link = serial.Serial(PORT, BAUD, timeout=0.1)
        print("Serial open on", PORT)
    except serial.SerialException as e:
        print("No serial:", e)
        link = None

    delay = 1.0 / RATE
    last_print = 0

    while True:
        ok, image = cam.read()
        if not ok:
            continue

        colour, angle = vision.find_pillar(image)

        if link:
            message = "PIL,%s,%.1f\n" % (colour, angle)
            link.write(message.encode())

        # Print once a second so the terminal stays readable.
        if time.time() - last_print > 1.0:
            last_print = time.time()
            print("seeing: %-5s  angle: %+.1f" % (colour, angle))

        if show:
            import cv2
            cv2.imshow("camera", image)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

        time.sleep(delay)

    cam.release()
    if link:
        link.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
