# pi/ — Raspberry Pi vision node

**Status: half built.** The camera pipeline works and the serial message goes
out, but the colour detection is not calibrated yet and the pillar-choosing
rule is a placeholder. See "What is left" below.

The Pi looks for the red and green traffic signs and tells the ESP32 what it
sees. The ESP32 decides what the car does.

| File | What it does |
|---|---|
| `vision.py` | Finds a red or green pillar and works out its angle |
| `main.py` | Main loop — read camera, find pillar, send to ESP32 |
| `calibrate.py` | Finds the colour numbers `vision.py` needs |

## The message

```
PIL,red,-12.3
```

Colour, then angle in degrees. Negative is left, positive is right.

## Setup

```bash
sudo apt install python3-opencv python3-serial
```

Turn off the serial login shell or the port stays busy:

```
sudo raspi-config → Interface Options → Serial Port
    login shell over serial : NO
    serial hardware enabled : YES
```

**Turn off Wi-Fi and Bluetooth.** Rule 11.10 does not allow wireless during
rounds, and a Pi has both switched on by default. Add to `/boot/firmware/config.txt`:

```
dtoverlay=disable-wifi
dtoverlay=disable-bt
```

Reboot and check with `ip link` — no `wlan0` should be listed.

## Wiring

| Pi | | ESP32 |
|---|---|---|
| GPIO14 / TXD | → | GPIO16 |
| GPIO15 / RXD | ← | GPIO17 |
| GND | — | GND |

Both run at 3.3 V so nothing extra is needed. The shared ground is not
optional — without it the link produces nothing.

## Running

```bash
python3 calibrate.py      # first, on your own field
python3 main.py --show    # at the bench, with the camera window
python3 main.py           # on the car
```

## What is left

- [ ] **Calibrate the colours.** `vision.py` has zeros in it. Nothing is
      detected until `calibrate.py` has been run for red and for green.
- [ ] **Measure `CAMERA_ANGLE`.** 62.0 is a guess from the datasheet.
- [ ] **Decide which pillar to obey.** Right now it picks the biggest blob.
      That is not the same as the one that matters — a pillar straight ahead
      is more urgent than a bigger one off to the side. Work out the rule you
      want and write down why in the engineering journal.
- [ ] **Estimate distance.** Currently only the angle is sent. A taller blob
      means a closer pillar, so pillar height in pixels could give a distance.
- [ ] **Handle bad messages.** If a byte gets corrupted on the wire the ESP32
      has no way to tell. Adding a checksum would fix that.
- [ ] **ESP32 side.** Nothing reads these messages yet.
- [ ] **Measure the Pi's power draw** and add it to the power budget in the journal.
