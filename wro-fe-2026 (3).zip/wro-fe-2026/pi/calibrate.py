#!/usr/bin/env python3
"""
calibrate.py - find the HSV colour numbers that vision.py needs.

Run this on your own field, in the lighting you will compete in. Colour
numbers do not transfer between cameras or rooms, so numbers copied from
someone else's project will not work.

    python3 calibrate.py

Drag the sliders until only the pillar shows up white in the mask window.
Press q to quit and print the numbers.
"""

import cv2
import numpy as np

WINDOW = "calibrate"


def nothing(x):
    pass


def main():
    cam = cv2.VideoCapture(0)
    cam.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    if not cam.isOpened():
        print("Camera did not open.")
        return

    cv2.namedWindow(WINDOW)
    cv2.createTrackbar("H low",  WINDOW, 0,   179, nothing)
    cv2.createTrackbar("H high", WINDOW, 179, 179, nothing)
    cv2.createTrackbar("S low",  WINDOW, 0,   255, nothing)
    cv2.createTrackbar("S high", WINDOW, 255, 255, nothing)
    cv2.createTrackbar("V low",  WINDOW, 0,   255, nothing)
    cv2.createTrackbar("V high", WINDOW, 255, 255, nothing)

    print("Point the camera at ONE pillar.")
    print("Drag sliders until only that pillar is white. Press q when done.")

    while True:
        ok, image = cam.read()
        if not ok:
            continue

        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

        low = np.array([cv2.getTrackbarPos("H low", WINDOW),
                        cv2.getTrackbarPos("S low", WINDOW),
                        cv2.getTrackbarPos("V low", WINDOW)])
        high = np.array([cv2.getTrackbarPos("H high", WINDOW),
                         cv2.getTrackbarPos("S high", WINDOW),
                         cv2.getTrackbarPos("V high", WINDOW)])

        mask = cv2.inRange(hsv, low, high)

        both = np.hstack([image, cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)])
        cv2.imshow(WINDOW, both)

        if cv2.waitKey(1) & 0xFF == ord("q"):
            print("")
            print("Paste into vision.py:")
            print("")
            print("    LOW  = (%d, %d, %d)" % (low[0], low[1], low[2]))
            print("    HIGH = (%d, %d, %d)" % (high[0], high[1], high[2]))
            print("")
            print("Do it once for red and once for green.")
            break

    cam.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
