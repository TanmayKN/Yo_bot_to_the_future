"""
vision.py - find the red and green traffic signs in the camera image.

Red pillar   = pass it on the right
Green pillar = pass it on the left

NOT FINISHED. The HSV colour values below are all zeros. Run calibrate.py on
your own field and paste the real numbers in, or nothing will be detected.
"""

import cv2
import numpy as np

WIDTH = 640
HEIGHT = 480

# How wide the camera can see, in degrees. Measure yours with calibrate.py.
CAMERA_ANGLE = 62.0

# --- FILL THESE IN FROM calibrate.py -------------------------------------
# Format: (hue, saturation, value)

RED_LOW    = (0, 0, 0)
RED_HIGH   = (0, 0, 0)

GREEN_LOW  = (0, 0, 0)
GREEN_HIGH = (0, 0, 0)

# -------------------------------------------------------------------------

MIN_SIZE = 300      # ignore blobs smaller than this many pixels


def open_camera():
    """Start the camera and return it."""
    cam = cv2.VideoCapture(0)
    cam.set(cv2.CAP_PROP_FRAME_WIDTH, WIDTH)
    cam.set(cv2.CAP_PROP_FRAME_HEIGHT, HEIGHT)
    return cam


def find_biggest(mask):
    """
    Find the biggest blob in a black-and-white mask.
    Returns (centre_x, size), or None if nothing is big enough.
    """
    blobs, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    best = None
    best_size = MIN_SIZE

    for blob in blobs:
        size = cv2.contourArea(blob)
        if size > best_size:
            best_size = size
            x, y, w, h = cv2.boundingRect(blob)
            best = (x + w // 2, int(size))

    return best


def angle_of(x):
    """Turn a pixel position into an angle from the centre of the image."""
    offset = (x - WIDTH / 2) / (WIDTH / 2)    # -1.0 on the left, +1.0 on the right
    return offset * (CAMERA_ANGLE / 2)


def find_pillar(image):
    """
    Look for a pillar in the image.

    Returns (colour, angle).
    colour is "red", "green" or "none".
    angle is negative for left, positive for right.
    """
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

    red_mask = cv2.inRange(hsv, np.array(RED_LOW), np.array(RED_HIGH))
    green_mask = cv2.inRange(hsv, np.array(GREEN_LOW), np.array(GREEN_HIGH))

    red = find_biggest(red_mask)
    green = find_biggest(green_mask)

    # Pick whichever blob is bigger, because bigger means closer.
    #
    # TODO: this is too simple. A pillar straight ahead matters more than a
    # bigger one off to the side that we will drive past anyway. Decide what
    # rule you actually want, then write down why in the engineering journal.
    if red and green:
        if red[1] > green[1]:
            return "red", angle_of(red[0])
        return "green", angle_of(green[0])
    if red:
        return "red", angle_of(red[0])
    if green:
        return "green", angle_of(green[0])

    return "none", 0.0
