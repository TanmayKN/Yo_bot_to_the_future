# other

Supporting material that does not fit the required folders.

- `legacy/` — superseded code versions, kept as iteration evidence
- `datasheets/` — component datasheets

The bill of materials is in the engineering journal.
