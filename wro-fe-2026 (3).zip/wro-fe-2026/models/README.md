# models

Fabrication files for every printed part on the vehicle.

## chassis/

| File | Bounding box | Triangles |
|---|---|---|
| `ackermann_chassis_assembly.stl` | 198.5 × 269.9 × 78.8 mm | 414,992 |
| `part_106.stl` | 12.1 × 9.0 × 5.0 mm | 2,868 |
| `part_107.stl` | 11.9 × 18.2 × 5.0 mm | 10,856 |
| `axle_adaptor.stl` | 20.0 × 20.0 × 55.0 mm | 532 |

## camera/

| File | Bounding box | Triangles |
|---|---|---|
| `camera_pi_mount.stl` | 30.0 × 39.2 × 58.4 mm | 1,704 |
| `camera_front_box_v003.stl` | 30.0 × 64.5 × 10.0 mm | 1,896 |
| `camera_back_cover_v002.stl` | 30.0 × 28.0 × 4.0 mm | 390 |

## _needs-review/

Four exports whose dimensions come out **exactly 10× the matching part**. Almost
certainly exported with centimetres selected instead of millimetres in Fusion 360's STL
dialogue. They are kept rather than deleted so nothing is lost, but they must not be
printed and should not be the versions a judge sees as final.

| File | Reported size | Probable intent |
|---|---|---|
| `part_106_10x.stl` | 120.5 × 89.5 × 50.0 mm | 10× of `chassis/part_106.stl` |
| `part_107_10x.stl` | 118.7 × 181.7 × 50.0 mm | 10× of `chassis/part_107.stl` |
| `part_108_10x.stl` | 118.7 × 181.7 × 50.0 mm | no mm-scale counterpart uploaded |
| `camera_pi_mount_10x.stl` | 120.5 × 105.5 × 50.0 mm | scale mismatch |

**Action needed:** re-export these from the Fusion source with units set to millimetres,
move them into `chassis/` or `camera/`, and delete this folder. `part_108` has no correct
version in the repository at all — that one needs a fresh export before submission.

## Missing

The Fusion 360 source files (`.f3d`) are not in the repository yet. Shipping only meshes
means another team can print the parts but cannot modify them, which caps what the
reproducibility criterion can award. Export the source alongside the STLs.

See `PRINT_SETTINGS.md` for material and slicer settings.
