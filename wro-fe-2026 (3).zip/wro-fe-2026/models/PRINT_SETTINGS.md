# Print settings

Printer: `[FILL: Bambu Lab A1]` · Slicer: `[FILL: Bambu Studio]`

| Part | Material | Layer height | Infill | Walls | Supports | Notes |
|---|---|---|---|---|---|---|
| `chassis/ackermann_chassis_assembly.stl` | `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` | Main deck |
| `chassis/part_106.stl` | `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` | |
| `chassis/part_107.stl` | `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` | |
| `chassis/axle_adaptor.stl` | `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` | Load-bearing — see below |
| `camera/camera_pi_mount.stl` | `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` | Rigidity matters — see below |
| `camera/camera_front_box_v003.stl` | `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` | |
| `camera/camera_back_cover_v002.stl` | `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` | `[FILL]` | |

## Parts where orientation is a design decision, not a convenience

**`axle_adaptor.stl`** transmits drive torque. Printed with layers perpendicular to the
axle, the load tries to peel the layers apart and the part shears along a layer line.
Orient so the torque works across layers rather than between them, and raise wall count
rather than infill — the strength is in the perimeters.

**`camera_pi_mount.stl`** is 58.4 mm tall and holds the camera. Any flex here rotates the
camera's aim under acceleration, and a change in aim angle is indistinguishable in
software from the track actually moving. Print solid or near-solid; this is the one part
where mass is worth spending on stiffness. Record the material and wall count used, and
if you stiffen it later, log it in the engineering journal as an iteration.

## Print log

| Date | Part | Settings changed | Outcome |
|---|---|---|---|
| | | | |
