# src

Control software for every component that was programmed.

Naming: lowercase, underscores, real file extensions. `wall_following.cpp`,
not `V2 code`. Judges open these in the GitHub browser — no extension means
no syntax highlighting, which means grey unreadable text.

Suggested layout:

- `main.cpp` — entry point
- `config.h` — pin definitions and tunable constants in one place
- `steering.cpp` / `.h`
- `sensors.cpp` / `.h`
- `obstacle.cpp` / `.h`

Comment the code. Rule 7 requires it explicitly.
