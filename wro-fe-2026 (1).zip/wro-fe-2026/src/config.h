// =====================================================================
//  config.h — pin map and tunable constants
//  WRO Future Engineers 2026
//
//  All hardware-dependent numbers live here. Nothing else in the
//  codebase should contain a raw GPIO number or a magic constant.
// =====================================================================
#pragma once

// ---------- Motor driver (L298N) ----------
#define PIN_MOTOR_ENA   18   // PWM, LEDC channel 0
#define PIN_MOTOR_IN1   19
#define PIN_MOTOR_IN2   23

#define MOTOR_PWM_FREQ  5000 // Hz — L298N tolerant range
#define MOTOR_PWM_RES   10   // bits (0-1023)

// ---------- Steering (PCA9685 over I2C bus 0) ----------
#define PIN_I2C0_SDA    21
#define PIN_I2C0_SCL    22
#define I2C0_FREQ       400000

#define PCA9685_ADDR    0x40
#define SERVO_CH        0    // steering servo channel

#define SERVO_CENTER_US 1500
#define SERVO_LEFT_US   1100 // TODO: measure actual mechanical limit
#define SERVO_RIGHT_US  1900 // TODO: measure actual mechanical limit

// ---------- IMU (BNO055 on dedicated I2C bus 1) ----------
#define PIN_I2C1_SDA    32
#define PIN_I2C1_SCL    33
#define I2C1_FREQ       100000
#define BNO055_ADDR     0x28

// ---------- Ultrasonic sensors ----------
#define PIN_US_L_TRIG   25
#define PIN_US_L_ECHO   36   // input-only pin
#define PIN_US_F_TRIG   26
#define PIN_US_F_ECHO   39   // input-only pin
#define PIN_US_R_TRIG   27
#define PIN_US_R_ECHO   34   // input-only pin

// NOTE: 5V HC-SR04 echo lines require a divider down to 3.3V.
// 3.3V HC-SR04P variants connect directly.

// ---------- Raspberry Pi link (UART2) ----------
#define PIN_RPI_RX      16
#define PIN_RPI_TX      17
#define RPI_BAUD        115200

// ---------- Start button ----------
#define PIN_START_BTN   4    // rule 9.11: exactly ONE start button

// ---------- Control tuning ----------
#define HEADING_KP      2.0f
#define HEADING_KI      0.0f
#define HEADING_KD      0.4f

#define WALL_KP         1.2f
#define WALL_KD         0.3f

#define TARGET_LAPS     3
