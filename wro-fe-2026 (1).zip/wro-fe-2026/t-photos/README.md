# t-photos

Two team photos, per WRO Future Engineers requirements:

- `team-official.jpg` — formal photo, all members visible
- `team-funny.jpg` — informal photo, all members visible

Delete this file once both photos are in place.
