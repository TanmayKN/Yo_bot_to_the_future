# Bill of materials

| Qty | Component | Part number | Supplier | Notes |
|---|---|---|---|---|
| 1 | ESP32 dev board | | | Main controller |
| 1 | PCA9685 servo driver | HW-170 | | I2C, 12-bit |
| 1 | BNO055 IMU | | | IMUPLUS mode, magnetometer off |
| 3 | Ultrasonic sensor | HC-SR04 / HC-SR04P | | Confirm variant |
| 1 | L298N motor driver | | | |
| 1 | Steering servo | | | Confirm voltage rating |
| 3 | 18650 Li-ion cell | | | 3S pack, 11.1 V nominal |
| 1 | Buck converter | | | Servo rail |
