# legacy

Earlier code versions, kept deliberately.

Each file here should be paired with a line in the main README explaining
what changed and why. "V1 used bang-bang steering and oscillated on corners;
V2 replaced it with a P controller" is worth points. A folder of old files
with no explanation is not.
