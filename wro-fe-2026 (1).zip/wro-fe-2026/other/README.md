# other

Supporting material that does not fit the required folders.

- `legacy/` — superseded code versions, kept as iteration evidence
- `datasheets/` — component datasheets
- `BOM.md` — bill of materials with part numbers and suppliers
