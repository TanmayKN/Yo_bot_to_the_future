# v-photos

Six photos of the vehicle. Rules require every side plus top and bottom:

- `front.jpg`
- `back.jpg`
- `left.jpg`
- `right.jpg`
- `top.jpg`
- `bottom.jpg`

Shoot on a plain background, good light, vehicle in competition condition
(all wiring tidy, no test leads hanging off). Judges use these to check
dimensions and construction — make them clear.

Delete this file once all six are in place.
