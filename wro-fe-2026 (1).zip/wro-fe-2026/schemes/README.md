# schemes

Schematic diagrams of all electromechanical components and how they connect.
Accepted formats: JPEG, PNG, PDF.

Expected files:

- `wiring-diagram.png` — full system wiring, power rails clearly separated
- `pinout.png` — ESP32 GPIO assignments
- `power-budget.png` (or a table in the README) — current draw per subsystem

Export these from your existing diagrams. Do not leave them as source files
only — judges must be able to view them in the browser.
