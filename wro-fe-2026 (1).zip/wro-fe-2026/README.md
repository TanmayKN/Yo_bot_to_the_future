# WRO Future Engineers 2026 — Autonomous Vehicle

**Team:** `[TEAM NAME]` · **Country:** India · **Category:** Future Engineers

> **Paste your existing README content into the sections below.** The headings
> are ordered to match the five judging criteria in Appendix C of the rules, so
> a judge working down the rubric finds each criterion in sequence. Delete this
> blockquote before pushing.

---

## Repository contents

| Folder | Contents |
|---|---|
| `t-photos/` | Team photos — one official, one informal |
| `v-photos/` | Six vehicle photos — all sides, top, bottom |
| `video/` | `video.md` with links to driving demonstration videos |
| `schemes/` | Wiring and pinout diagrams |
| `src/` | Control software |
| `models/` | CAD, STL and fabrication files |
| `other/` | BOM, datasheets, superseded code versions |
| `docs/` | Engineering journal and testing log |

---

## 1. Overview

*What the vehicle is, in three or four sentences. Drive type, controller,
sensing approach, and the single design idea the rest of the document
justifies.*

---

## 2. Mobility and mechanical design
*Rubric criterion 1*

### 2.1 Chassis
### 2.2 Drive system
*Which axle drives, motor selection, gearing.*

### 2.3 Steering
*Ackermann geometry. Rule 11.3 requires four wheels, one driving axle, one
steering actuator — differential drive is a disqualification.*

### 2.4 Torque and speed reasoning
*The calculation, and what it ruled out. This is the difference between a 4
and a 6 on this criterion.*

### 2.5 Iterations
*What changed between versions, and the measurement that prompted it.*

### 2.6 Compliance check

| Limit | Rule | Ours |
|---|---|---|
| Footprint ≤ 300 × 200 mm | 11.1 | |
| Height ≤ 300 mm | 11.1 | |
| Mass ≤ 1.5 kg | 11.2 | |
| Four wheels, one driving axle, one steering actuator | 11.3 | |
| No omni / ball caster / spherical wheels | 11.4 | |

---

## 3. Power and sensor architecture
*Rubric criterion 2*

### 3.1 Power distribution
*Pack chemistry and configuration, regulation, which rail feeds what.*

### 3.2 Power budget

| Subsystem | Nominal current | Peak current |
|---|---|---|
| | | |

### 3.3 Sensor selection and placement
*Why each sensor, and why it sits where it sits. Tie placement to field
geometry — wall heights, pillar dimensions, lighting.*

### 3.4 Calibration

### 3.5 Failure modes considered
*Noise, glare, brownout, interference. What was done about each.*

---

## 4. Software architecture and obstacle strategy
*Rubric criterion 3*

### 4.1 Module structure
### 4.2 State machine
*Include the diagram. A flowchart caps at level 4; a state machine with
rationale is what the level-6 descriptor asks for.*

### 4.3 Lane following
### 4.4 Obstacle strategy
*Red pillar passed on the right, green on the left (rule 9.19). Signs must be
obeyed on the three scored laps only; on the route to the parking lot they may
be passed either side, but still must not be moved.*

### 4.5 Parallel parking
### 4.6 Edge cases handled
### 4.7 Tuning process and metrics

> **Wireless check.** Rule 11.10 prohibits RF, Bluetooth and Wi-Fi during
> competition rounds; if built into the controller it must be disabled, and
> judges may inspect the code to confirm. Ensure no `WiFi.h` include reaches
> the competition build.

---

## 5. Systems thinking and engineering decisions
*Rubric criterion 4*

### 5.1 Constraints
*Weight, power, processing, budget, time.*

### 5.2 Trade-offs
*Use the form the rubric literally quotes: "we chose X instead of Y because…"
backed by data or a test result.*

### 5.3 Risk table

| Risk | Likelihood | Effect | Mitigation |
|---|---|---|---|
| | | | |

### 5.4 Version history
*V1 → V2 → V3, and what drove each change.*

---

## 6. Build and run

### 6.1 Requirements
### 6.2 Wiring
*Point to `schemes/`.*
### 6.3 Flashing
### 6.4 Starting the vehicle
*Rule 9.10 and 9.11: one switch to power on, one button to start. Nothing else.*

---

## 7. Team

---

*README length check: the rubric expects at least 5000 characters for a level 4
on Reproducibility and GitHub Quality. Run `wc -m README.md` before pushing.*
