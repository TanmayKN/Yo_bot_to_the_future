# models

Files used to fabricate vehicle parts: 3D printing, laser cutting, CNC.

Suggested layout:

- `stl/` — printable meshes
- `step/` or `f3d/` — parametric CAD source (Fusion 360)
- `PRINT_SETTINGS.md` — material, layer height, infill, supports for each part

Including the CAD source, not just STLs, is what moves this from "competent"
to "advanced" on the reproducibility criterion.
