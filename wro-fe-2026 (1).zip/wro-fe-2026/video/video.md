# Driving demonstration videos

Rules require one video per challenge, each showing at least 30 seconds of
continuous autonomous driving. YouTube links, public or unlisted-with-link.

## Open Challenge
[LINK HERE]

## Obstacle Challenge
[LINK HERE]

Recorded: [DATE]
