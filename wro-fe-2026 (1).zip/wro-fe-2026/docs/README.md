# docs

Working documents that are not the main README:

- `ENGINEERING_JOURNAL.pdf` — the structured journal
- `TESTING.md` — test log: what was tried, what the numbers were, what changed

A documented testing workflow is named explicitly in the level-6 descriptor
for Reproducibility and GitHub Quality.
