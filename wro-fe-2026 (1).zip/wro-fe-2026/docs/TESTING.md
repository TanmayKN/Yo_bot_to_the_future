# Testing log

One row per test session. This file is what turns "we built a robot" into
"we engineered a robot" — the rubric asks for evidence of iteration, and a
dated log with numbers is the cheapest way to provide it.

| Date | What was tested | Runs | Result / metric | Change made |
|---|---|---|---|---|
| | | | | |

## How to use this

Record a number, not an impression. "Completed 17/20 laps without
intervention" beats "worked better." The level-6 descriptors ask
specifically for metrics used for performance evaluation.

## Open questions

- [ ] Confirm ultrasonic variant (5V HC-SR04 vs 3.3V HC-SR04P)
- [ ] Measure actual servo mechanical limits, update `config.h`
- [ ] Verify vehicle mass under 1.5 kg with batteries installed
- [ ] Verify footprint under 300 x 200 mm, height under 300 mm
